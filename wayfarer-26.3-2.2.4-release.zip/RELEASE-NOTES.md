# Wayfarer Travel Kit v2.2.4

Minecraft 26.3 / Forge 66 / Java 25

## Highlights

- Five material tiers: fireproof wood, lava, void, star, abyss
- Fourth dimension (Abyss) with exclusive ores, 2 structures, a boss and a neutral NPC
- Six bosses summoned from the Summon Altar, each with a boss bar
- Five generated structures: Firelands Village, Void Temple, Lava Temple, Abyss Ruin, Abyss Obelisk, Factory Ruin
- Power network: cables, cells, void generator, electric furnace, item pipes, auto-crafter, teleporter, multiblock factory core
- Utilities: bestiary GUI, recipe book (R), ore detector, waypoint shard, 27-slot backpack, blueprint copier, energy HUD
- `/sethome`, `/home`, `/back`, `/wayfarer help|locate|bestiary|energy`, grave chest on death

## Fixes in this build

- Fixed the Ember Wisp having no renderer (client crash `renderer is null`)
- Fixed friendly mobs missing the attack-damage attribute (crash on River Otter attacking)
- Added spawn eggs for all seven boss/sentinel mobs
- Abyss gateway now scans downward from y=190 for a safe landing spot
- Fireland temples, bluprints, energy HUD and bestiary added across 2.0.x - 2.2.x

## Files

| File | Notes |
|---|---|
| `wayfarer-26.3-2.2.4.jar` | Mod jar - put in `mods/` |
| `wayfarer-26.3-2.2.4-release.zip` | Jar + README + CHANGELOG + cover |
| `cover_240x150.png` | Store cover |

## Known limitations

Firelands biome requires a new world; the Nether "lava sea" is lakes, not a biome; Abyss weather is static; Abyss fluid is a gel block; most new mobs reuse vanilla geometry.

Full documentation: see README.md in the repository.
